import java.util.HashSet;
public class HashSetExample {
   public static void main(String args[]) {
      // HashSet declaration
      HashSet<String> hset = 
               new HashSet<String>();

      // Adding elements to the HashSet
      hset.add("Apple");
      hset.add("Mango");
      hset.add("Grapes");
      hset.add("Orange");
      hset.add("Fig");
      //Addition of duplicate elements
      hset.add("Apple");
      hset.add("Mango");
      //Addition of null values
      hset.add(null);
      hset.add(null);

      //Displaying HashSet elements
      System.out.println(hset);


/* public void clear(): It removes all the elements
      * from HashSet. The set becomes empty after this
      * method gets called.
      */
     hset.clear();
 
     // Display HashSet content again
     System.out.println("After: HashSet contains: "+ hset);

// Creating an Array
     String[] array = new String[hset.size()];
     hset.toArray(array);

// Displaying Array elements
     System.out.println("Array elements: ");
     for(String temp : array){
        System.out.println(temp);
     }


    }
}

