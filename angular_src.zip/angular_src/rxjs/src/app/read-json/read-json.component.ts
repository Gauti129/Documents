import { Component, OnInit } from '@angular/core';
import 'rxjs/Rx';
import { Http,Response} from '@angular/http';
import { Observable} from 'rxjs/Rx'

@Component({
  selector: 'app-read-json',
  templateUrl: './read-json.component.html',
  styleUrls: ['./read-json.component.css']

})
export class ReadJsonComponent implements OnInit {
  response:any;
  result:Array<Object>;
  constructor(http: Http) {
    console.log("Frinds are  being called");
    http.get('./assets/frinds.json')
              .map(response => response.json())
              .subscribe(result => this.result=result);

              console.log(this.result);
   }

  ngOnInit() {
  }

}
