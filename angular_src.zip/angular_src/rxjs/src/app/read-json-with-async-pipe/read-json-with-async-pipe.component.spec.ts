import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReadJsonWithAsyncPipeComponent } from './read-json-with-async-pipe.component';

describe('ReadJsonWithAsyncPipeComponent', () => {
  let component: ReadJsonWithAsyncPipeComponent;
  let fixture: ComponentFixture<ReadJsonWithAsyncPipeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReadJsonWithAsyncPipeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReadJsonWithAsyncPipeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
