import { Component, OnInit } from '@angular/core';
import 'rxjs/Rx';
import {Http} from '@angular/http';

@Component({
  selector: 'app-read-json-with-async-pipe',
  templateUrl: './read-json-with-async-pipe.component.html',
  styleUrls: ['./read-json-with-async-pipe.component.css']
})
export class ReadJsonWithAsyncPipeComponent implements OnInit {
  result:any;
  constructor(private http : Http) { }

  ngOnInit() {
    this.result = this.http.get('./assets/frinds.json')
                  .map(response=> response.json());  
  }

}
