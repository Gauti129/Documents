import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SpringWebServiceComponent } from './spring-web-service.component';

describe('SpringWebServiceComponent', () => {
  let component: SpringWebServiceComponent;
  let fixture: ComponentFixture<SpringWebServiceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SpringWebServiceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SpringWebServiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
