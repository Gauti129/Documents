import { Component, OnInit } from '@angular/core';
import 'rxjs/Rx';
import {Http,Response} from '@angular/http';


@Component({
  selector: 'app-spring-web-service',
  templateUrl: './spring-web-service.component.html',
  styleUrls: ['./spring-web-service.component.css']
})
export class SpringWebServiceComponent implements OnInit {
  result:any;

  constructor(private http:Http) 
  
  { 
  
  this.result=http.get('http://rest-service.guides.spring.io/greeting').map(response=>JSON.stringify(response.text()));
  
   
  
  }
  ngOnInit() {
   
  }

}
