import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { XmlServiceComponent } from './xml-service.component';

describe('XmlServiceComponent', () => {
  let component: XmlServiceComponent;
  let fixture: ComponentFixture<XmlServiceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ XmlServiceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(XmlServiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
