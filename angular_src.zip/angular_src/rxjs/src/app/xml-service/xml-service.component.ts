import { Component, OnInit } from '@angular/core';
import 'rxjs/Rx';
import {Http,Response,Jsonp} from '@angular/http';


@Component({
  selector: 'app-xml-service',
  templateUrl: './xml-service.component.html',
  styleUrls: ['./xml-service.component.css']
})
export class XmlServiceComponent implements OnInit {
  result:any;

  constructor( http:Jsonp) 
  
  { 
  
  http.get('http://www.nerddinner.com/Services/OData.svc/Dinners?$format=json&$callback=JSONP_CALLBACK')
              .map(response=>response.text())
              .subscribe(
                function(response){
                  console.log("Success Responce" + response);
                },
                function(error){
                  console.log("Error happened" + error);
                },
                function(){
                  console.log("the subscription is compleated");
                }
              );
          
  }            
  ngOnInit() {
  }

}
