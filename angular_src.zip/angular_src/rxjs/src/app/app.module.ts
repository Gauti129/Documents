import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {HttpModule, JsonpModule} from '@angular/http'

import { AppComponent } from './app.component';
import { ReadJsonComponent } from './read-json/read-json.component';
import { ReadJsonWithAsyncPipeComponent } from './read-json-with-async-pipe/read-json-with-async-pipe.component';
import { SpringWebServiceComponent } from './spring-web-service/spring-web-service.component';
import { ComplexJsonComponent } from './complex-json/complex-json.component';
import { XmlServiceComponent } from './xml-service/xml-service.component';


@NgModule({
  declarations: [
    AppComponent,
    ReadJsonComponent,
    ReadJsonWithAsyncPipeComponent,
    SpringWebServiceComponent,
    ComplexJsonComponent,
    XmlServiceComponent
  ],
  imports: [
    BrowserModule,HttpModule,JsonpModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
