import { Component, OnInit } from '@angular/core';
import 'rxjs/Rx';
import {Http,Response,Jsonp} from '@angular/http';

@Component({
  selector: 'app-complex-json',
  templateUrl: './complex-json.component.html',
  styleUrls: ['./complex-json.component.css']
})
export class ComplexJsonComponent implements OnInit {
  result:any;

  constructor(private http:Jsonp) 
  
  { 
  
  this.result=http.get('https://demos.telerik.com/kendo-ui/service/StockData?callback=JSONP_CALLBACK')
              .map(response=>JSON.stringify(response.text()));
  
   
  
  }

  ngOnInit() {
  }

}
