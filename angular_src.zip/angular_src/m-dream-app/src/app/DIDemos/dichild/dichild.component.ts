import { Component, OnInit } from '@angular/core';
import {UniqueNumber} from './../UniqueService';
import { Hamburger,CheeseHamburger,DoubleHamburger} from './../Hamburgers';
@Component({
  selector: 'app-dichild',
  templateUrl: './dichild.component.html',
  styleUrls: ['./dichild.component.css'],
  providers:[{provide:Hamburger, useClass:DoubleHamburger}]
  
})
export class DichildComponent implements OnInit {
res:string;
burgerType:string;
  constructor(u:UniqueNumber,h:Hamburger) {
    this.res=u.result;
    this.burgerType="you are eatinh "+h.type;
   }

  ngOnInit() {
  }

}
