import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DichildComponent } from './dichild.component';

describe('DichildComponent', () => {
  let component: DichildComponent;
  let fixture: ComponentFixture<DichildComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DichildComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DichildComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
