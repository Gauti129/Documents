import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DiparentComponent } from './diparent.component';

describe('DiparentComponent', () => {
  let component: DiparentComponent;
  let fixture: ComponentFixture<DiparentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DiparentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DiparentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
