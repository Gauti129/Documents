import { Component, OnInit } from '@angular/core';
import {UniqueNumber} from './../UniqueService'
import { Hamburger,CheeseHamburger,DoubleHamburger} from './../Hamburgers';

const isProd=true; 

export let BurgerFactory= {              //fectory method
  provide:Hamburger,
  useFactory:()=>
  {
    if(isProd)
    {
      return new DoubleHamburger();
    }
    else
    {
      return new CheeseHamburger();
    }
  }
}

@Component({
  selector: 'app-diparent',
  templateUrl: './diparent.component.html',
  styleUrls: ['./diparent.component.css'],
  providers:[Hamburger,DoubleHamburger,CheeseHamburger,BurgerFactory]
 
})
export class DiparentComponent implements OnInit {
  res:string;
  burger:string;
  constructor(u:UniqueNumber,h:Hamburger) {
    this.res=u.result;
    this.burger=h.type;

   }

  ngOnInit() {
  }

}
