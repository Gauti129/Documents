import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { HelloComponent } from './hello/hello.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { PipesDemoComponent } from './pipes-demo/pipes-demo.component';
import { CapitalizePipe } from './Capitalize.Pipe';
import { MyNewPipePipe } from './my-new-pipe.pipe';
import { DiparentComponent } from './DIDemos/diparent/diparent.component';
import { DichildComponent } from './DIDemos/dichild/dichild.component';
import { UniqueNumber } from './DIDemos/UniqueService';


@NgModule({
  declarations: [
    AppComponent,
    HelloComponent,
    ParentComponent,
    ChildComponent,
    PipesDemoComponent,
    CapitalizePipe,
    MyNewPipePipe,
    DiparentComponent,
    DichildComponent
  ],
  imports: [
    BrowserModule, FormsModule
  ],
  providers: [UniqueNumber],
  bootstrap: [AppComponent]
})
export class AppModule { }
