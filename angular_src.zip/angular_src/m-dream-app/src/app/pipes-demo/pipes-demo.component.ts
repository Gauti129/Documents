import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipes-demo',
  templateUrl: './pipes-demo.component.html',
  styleUrls: ['./pipes-demo.component.css']
})
export class PipesDemoComponent implements OnInit {
   firstName:string;
   lastName:string;
   today=new Date(); //js
    str:string="hello world";
  constructor() {
    this.firstName="alex";
    this.lastName="steve";
   }

  ngOnInit() {
  }

}
