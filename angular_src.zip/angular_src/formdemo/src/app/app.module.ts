import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule} from '@angular/forms'


import { AppComponent } from './app.component';
import { SignupTemplateComponent } from './signup-template/signup-template.component';
import { SignupReactiveComponent } from './signup-reactive/signup-reactive.component';
import { ReactiveWithFormBuilderComponent } from './reactive-with-form-builder/reactive-with-form-builder.component';
import {ErrorsComponent } from './errors.component'
import { AgeValidatorDirective } from './age-validator.directive';
import { EmailValidatorDirective } from './email-validator.directive';
import { ViewEncapDemoComponent } from './view-encap-demo/view-encap-demo.component';
import { MyNewDirectiveDirective } from './my-new-directive.directive';
import { ForIfComponentComponent } from './for-if-component/for-if-component.component';


@NgModule({
  declarations: [
    AppComponent,
    SignupTemplateComponent,
    SignupReactiveComponent,
    ReactiveWithFormBuilderComponent, 
    ErrorsComponent,
    AgeValidatorDirective, 
    EmailValidatorDirective, ViewEncapDemoComponent, MyNewDirectiveDirective, ForIfComponentComponent
  ],
  imports: [
    BrowserModule, FormsModule, 
    ReactiveFormsModule, 
   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
