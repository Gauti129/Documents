import { Directive,ElementRef,Renderer, HostListener, Input} from '@angular/core';


@Directive({
  selector: 'div[appMyNewDirective],p'
})
export class MyNewDirectiveDirective {

  @Input('appMyNewDirective') highlightColor:string;

  constructor(private el: ElementRef, private ren:Renderer) {
    //this.ChangeColor('red');
   }
   private ChangeColor(colour:string)
   {
     this.ren.setElementStyle(this.el.nativeElement,'color',colour)
   }
   @HostListener('mouseenter')
   OnEnter(){
     //this.ChangeColor('red');
     this.ChangeColor(this.highlightColor);
   }
  
   @HostListener('mouseleave')
   OnExit(){
    //this.ChangeColor('blue');
    this.ChangeColor(null);
  }
  
}
