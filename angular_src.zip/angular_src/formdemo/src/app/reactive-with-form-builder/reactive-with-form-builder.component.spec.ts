import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReactiveWithFormBuilderComponent } from './reactive-with-form-builder.component';

describe('ReactiveWithFormBuilderComponent', () => {
  let component: ReactiveWithFormBuilderComponent;
  let fixture: ComponentFixture<ReactiveWithFormBuilderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReactiveWithFormBuilderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReactiveWithFormBuilderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
