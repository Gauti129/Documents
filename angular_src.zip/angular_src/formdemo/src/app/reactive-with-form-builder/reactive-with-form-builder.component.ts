import {    OnInit } from '@angular/core';
 
import { NgForm } from '@angular/forms';
import { Component, ViewChild } from '@angular/core';
import {
  FormGroup,
  FormControl,
  Validators,
  FormBuilder,
} from '@angular/forms';

@Component({
  selector: 'app-reactive-with-form-builder',
  templateUrl: './reactive-with-form-builder.component.html',
  styleUrls: ['./reactive-with-form-builder.component.css']
})
export class ReactiveWithFormBuilderComponent implements OnInit {

  validateForm: FormGroup;
 
 
  ngOnInit() {
  }
 
  constructor(private form: FormBuilder) {
    this.validateForm = new FormGroup({
      'name': new FormControl(),
      'email': new FormControl(),
      'age': new FormControl(),
      'address': new FormGroup({
        'country': new FormControl(),
        'city': new FormControl()
      })
    });
  }
 
  register(validateForm: NgForm) {
    console.log('Registration successful.');
    console.log(validateForm.value);
    alert("Hi "+validateForm.value.name+" you information are valid.")
  }
}
