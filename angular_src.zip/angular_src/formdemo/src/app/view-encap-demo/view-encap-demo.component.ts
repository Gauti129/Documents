import { Component, OnInit, style,ViewEncapsulation} from '@angular/core';

@Component({
  selector: 'app-view-encap-demo',
  //encapsulation:ViewEncapsulation.Emulated
  //encapsulation:ViewEncapsulation.Native
  encapsulation:ViewEncapsulation.None
,
  template:
  `
    <div class="test">
    <div>
      Title:
      </div>
      <input type="text" [(ngModel)]="title">
      </div>
      

  `,
 styles:[`
  .test {
    padding: 10px;
    // background : red;
  }
 `]
})
export class ViewEncapDemoComponent implements OnInit {
title:string;
  constructor() { 
    this.title="jfkfj";
  }

  ngOnInit() {
  }

}
