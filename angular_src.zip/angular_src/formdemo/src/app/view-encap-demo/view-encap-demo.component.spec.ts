import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewEncapDemoComponent } from './view-encap-demo.component';

describe('ViewEncapDemoComponent', () => {
  let component: ViewEncapDemoComponent;
  let fixture: ComponentFixture<ViewEncapDemoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewEncapDemoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewEncapDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
