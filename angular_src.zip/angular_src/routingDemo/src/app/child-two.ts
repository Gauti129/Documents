import { Component } from '@angular/core';
 
@Component({
  selector: 'child-two',
  template: 'Child Two'
})
export default class ChildTwo {
}