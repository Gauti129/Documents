import { Component } from '@angular/core';
 
@Component({
  selector: 'child-one',
  template: 'Child One'
})
export default class ChildOne {
}